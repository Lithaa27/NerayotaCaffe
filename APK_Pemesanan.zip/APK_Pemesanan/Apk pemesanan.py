import tkinter as tk
from tkinter import messagebox

# # Data menu cafe
# menu_items = {
#     "Kopi Hitam": 10000,
#     "Cappuccino": 25000,
#     "Latte": 20000,
#     "Teh Hijau": 15000,
#     "Air Mineral": 5000,
#     "Brownies": 30000,
#     "Sandwich": 35000,
# }

# # Fungsi untuk menghitung total harga secara otomatis
# def calculate_total():
#     total = 0
#     for item, var in order_vars.items():
#         try:
#             quantity = int(var.get())
#             total += quantity * menu_items[item]
#         except ValueError:
#             messagebox.showerror("Error", "Masukkan jumlah yang valid!")
#             return
#     total_label.config(text=f"Total: Rp {total:,}")

# # Fungsi untuk reset input
# def reset_order():
#     for var in order_vars.values():
#         var.set("0")
#     calculate_total()  # Perbarui total setelah reset

# # Fungsi untuk konfirmasi pemesanan
# def confirm_order():
#     orders = []
#     for item, var in order_vars.items():
#         try:
#             quantity = int(var.get())
#             if quantity > 0:
#                 orders.append(f"{item} x {quantity}")
#         except ValueError:
#             messagebox.showerror("Error", "Masukkan jumlah yang valid!")
#             return

#     if not orders:
#         messagebox.showinfo("Info", "Belum ada pesanan!")
#     else:
#         order_summary = "\n".join(orders)
#         total_price = sum(int(var.get()) * menu_items[item] for item, var in order_vars.items() if int(var.get()) > 0)
        
#         # Menampilkan rincian pesanan dalam messagebox
#         payment_confirmation = messagebox.askyesno("Konfirmasi Pesanan", f"Pesanan Anda:\n{order_summary}\nTotal: Rp {total_price:,}\n\nApakah Anda ingin melanjutkan ke pembayaran?")
        
#         if payment_confirmation:
#             root.quit()  # Menutup jendela pemesanan
#             show_payment_menu(total_price)

# # Fungsi untuk menampilkan menu pembayaran
# def show_payment_menu(total_price):
#     payment_window = tk.Toplevel()
#     payment_window.title("Menu Pembayaran")
#     payment_window.geometry("400x300")
    
#     # Judul
#     header_label = tk.Label(payment_window, text="Pilih Metode Pembayaran", font=("Arial", 16, "bold"))
#     header_label.pack(pady=20)

#     # Opsi pembayaran
#     payment_methods = ["Tunai", "Kartu Kredit", "e-Wallet"]

#     def proceed_payment(method):
#         messagebox.showinfo("Pembayaran Diterima", f"Pembayaran dengan {method} diterima.\nTotal: Rp {total_price:,}\nTerima kasih!")
#         payment_window.destroy()  # Menutup menu pembayaran
        
#         # Menutup aplikasi utama dan kembali ke menu login
#         root.destroy()  # Menutup jendela pemesanan
#         open_login_window()  # Membuka jendela login kembali

#     # Tombol untuk setiap metode pembayaran
#     for method in payment_methods:
#         payment_button = tk.Button(payment_window, text=method, width=20, command=lambda m=method: proceed_payment(m))
#         payment_button.pack(pady=10)
    
#     # Menjalankan aplikasi
#     payment_window.mainloop()

# # Fungsi untuk membuka jendela login (sebelum pemesanan)
# def open_login_window():
#     global login_window
#     login_window = tk.Tk()
#     login_window.title("Login")
#     login_window.geometry("300x200")

#     # Label dan entry untuk nama customer
#     label_customer_name = tk.Label(login_window, text="Nama Customer:")
#     label_customer_name.pack(pady=5)
#     entry_customer_name = tk.Entry(login_window)
#     entry_customer_name.pack(pady=5)

#     # Tombol login
#     login_button = tk.Button(login_window, text="Login", command=lambda: check_login(entry_customer_name))
#     login_button.pack(pady=20)

#     # Menjalankan jendela login
#     login_window.mainloop()

# # Fungsi untuk mengecek login (nama customer)
# def check_login(entry_customer_name):
#     customer_name = entry_customer_name.get()

#     # Validasi nama customer (misalnya tidak boleh kosong)
#     if customer_name.strip():
#         login_window.destroy()  # Menutup jendela login dan membuka jendela utama
#         create_main_window(customer_name)
#     else:
#         messagebox.showerror("Login Failed", "Nama customer tidak boleh kosong!")

# # Membuat jendela utama untuk pemesanan
# def create_main_window(customer_name):
#     # Membuat jendela utama
#     global root
#     root = tk.Tk()
#     root.title(f"Aplikasi Pemesanan Kafe - {customer_name}")
#     root.geometry("400x500")

#     # Header
#     header_label = tk.Label(root, text="Menu Kafe", font=("Arial", 16, "bold"))
#     header_label.pack(pady=10)

#     # Frame untuk menu
#     menu_frame = tk.Frame(root)
#     menu_frame.pack(pady=10)

#     # Variabel untuk menyimpan jumlah pesanan
#     global order_vars
#     order_vars = {}

#     # Menampilkan daftar menu
#     for item, price in menu_items.items():
#         frame = tk.Frame(menu_frame)
#         frame.pack(fill="x", pady=5)

#         label = tk.Label(frame, text=f"{item} (Rp {price:,})", font=("Arial", 12), anchor="w")
#         label.pack(side="left", padx=5, expand=True)

#         var = tk.StringVar(value="0")
#         entry = tk.Entry(frame, textvariable=var, width=5, justify="center")
#         entry.pack(side="left", padx=5)

#         order_vars[item] = var

#         # Tombol "+" dan "-" untuk meningkatkan atau mengurangi jumlah pesanan
#         button_frame = tk.Frame(frame)
#         button_frame.pack(side="right", padx=5)

#         decrease_button = tk.Button(button_frame, text="-", command=lambda item=item: decrease_quantity(item))
#         decrease_button.pack(side="left", padx=5)

#         increase_button = tk.Button(button_frame, text="+", command=lambda item=item: increase_quantity(item))
#         increase_button.pack(side="left", padx=5)

#     # Label total harga
#     global total_label
#     total_label = tk.Label(root, text="Total: Rp 0", font=("Arial", 14))
#     total_label.pack(pady=10)

#     # Tombol aksi
#     button_frame = tk.Frame(root)
#     button_frame.pack(pady=10)

#     reset_button = tk.Button(button_frame, text="Reset", command=reset_order)
#     reset_button.pack(side="left", padx=5)

#     confirm_button = tk.Button(button_frame, text="Konfirmasi Pesanan", command=confirm_order)
#     confirm_button.pack(side="left", padx=5)

#     # Menjalankan aplikasi
#     root.mainloop()

# # Fungsi untuk menambah jumlah pesanan
# def increase_quantity(item):
#     current_value = int(order_vars[item].get())
#     order_vars[item].set(str(current_value + 1))
#     calculate_total()  # Hitung ulang total setelah perubahan

# # Fungsi untuk mengurangi jumlah pesanan
# def decrease_quantity(item):
#     current_value = int(order_vars[item].get())
#     if current_value > 0:
#         order_vars[item].set(str(current_value - 1))
#         calculate_total()  # Hitung ulang total setelah perubahan

# # Membuka jendela login saat aplikasi pertama kali dijalankan
# open_login_window()
