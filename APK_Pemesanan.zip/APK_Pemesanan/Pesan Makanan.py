import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

# Fungsi untuk pindah ke halaman menu
def go_to_menu():
    if username_entry.get().strip():
        login_frame.pack_forget()
        menu_frame.pack(fill="both", expand=True)
    else:
        messagebox.showerror("Error", "Masukkan username terlebih dahulu!")

# Fungsi untuk logout
def logout():
    menu_frame.pack_forget()
    username_entry.delete(0, tk.END)
    order.clear()
    total_label.config(text="Total: Rp 0")
    login_frame.pack(fill="both", expand=True)

# Fungsi untuk menambahkan pesanan
def add_to_order(item, price):
    if item in order:
        order[item]['quantity'] += 1
    else:
        order[item] = {'price': price, 'quantity': 1}
    update_total()

# Fungsi untuk mengurangi pesanan
def remove_from_order(item):
    if item in order:
        if order[item]['quantity'] > 1:
            order[item]['quantity'] -= 1
        else:
            del order[item]
        update_total()
    else:
        messagebox.showinfo("Info", f"Tidak ada {item} dalam pesanan.")

# Fungsi untuk memperbarui total harga
def update_total():
    total = sum(info['price'] * info['quantity'] for info in order.values())
    total_label.config(text=f"Total: Rp {total}")

# Fungsi untuk melihat pesanan
def view_order():
    if order:
        order_summary = "\n".join([f"{item}: {info['quantity']} x Rp {info['price']}" for item, info in order.items()])
        total = sum(info['price'] * info['quantity'] for info in order.values())
        messagebox.showinfo("Pesanan Anda", f"Pesanan:\n{order_summary}\n\nTotal: Rp {total}")
    else:
        messagebox.showinfo("Pesanan Anda", "Belum ada pesanan.")

# Inisialisasi tkinter
root = tk.Tk()
root.title("Aplikasi Pemesanan Makanan")
root.geometry("500x500")

# Daftar menu makanan dengan harga dan gambar
menu_items = {
    "Nasi Goreng": {"price": 15000, "image": "nasi_goreng.png"},
    "Mie Ayam": {"price": 12000, "image": "mie_ayam.jpg"},
    "Ayam Goreng": {"price": 17000, "image": "ayam_goreng.jpg"},
    "Sate Ayam": {"price": 20000, "image": "sate_ayam.png"},
    "Es Teh": {"price": 5000, "image": "es_teh.png"}
}

# Frame login dengan background gambar
login_frame = tk.Frame(root)
canvas = tk.Canvas(login_frame, width=500, height=500)
canvas.pack(fill="both", expand=True)

# Memuat gambar background
try:
    bg_image = Image.open("login_background.jpeg")
    bg_image = bg_image.resize((500, 500))  # Sesuaikan ukuran dengan window
    bg_photo = ImageTk.PhotoImage(bg_image)
    canvas.create_image(0, 0, image=bg_photo, anchor="nw")
except FileNotFoundError:
    messagebox.showwarning("Peringatan", "Gambar background tidak ditemukan!")

# Menambahkan elemen login di atas background
canvas.create_text(250, 100, text="Selamat Datang", font=("Arial", 24), fill="white")
canvas.create_text(250, 160, text="Masukkan Username", font=("Arial", 16), fill="white")

username_entry = tk.Entry(login_frame, font=("Arial", 14))
username_window = canvas.create_window(250, 200, window=username_entry, width=300)

login_button = tk.Button(login_frame, text="Login", font=("Arial", 14), command=go_to_menu)
login_button_window = canvas.create_window(250, 260, window=login_button, width=100)

# Frame menu
menu_frame = tk.Frame(root)
tk.Label(menu_frame, text="Menu Makanan", font=("Arial", 18)).pack(pady=20)
order = {}

# Menampilkan menu dengan gambar
for item, details in menu_items.items():
    try:
        img = Image.open(details["image"]).resize((50, 50))  # Ganti ukuran gambar jika diperlukan
        img_tk = ImageTk.PhotoImage(img)
    except FileNotFoundError:
        img_tk = None  # Gambar tidak ditemukan, gunakan placeholder

    frame = tk.Frame(menu_frame)
    frame.pack(pady=5, fill="x", padx=10)

    # Menampilkan gambar, nama, dan tombol
    if img_tk:
        tk.Label(frame, image=img_tk).pack(side="left", padx=10)
    tk.Label(frame, text=f"{item} - Rp {details['price']}", width=20, anchor="w").pack(side="left", padx=10)
    tk.Button(frame, text="+", command=lambda i=item, p=details['price']: add_to_order(i, p)).pack(side="left", padx=5)
    tk.Button(frame, text="-", command=lambda i=item: remove_from_order(i)).pack(side="left", padx=5)

    # Menyimpan gambar agar tidak dihapus oleh garbage collector
    if img_tk:
        menu_items[item]["image_tk"] = img_tk

total_label = tk.Label(menu_frame, text="Total: Rp 0", font=("Arial", 14))
total_label.pack(pady=20)
tk.Button(menu_frame, text="Lihat Pesanan", command=view_order).pack(pady=10)
tk.Button(menu_frame, text="Logout", command=logout).pack(pady=10)

# Tampilkan frame login di awal
login_frame.pack(fill="both", expand=True)

# Jalankan aplikasi
root.mainloop()
